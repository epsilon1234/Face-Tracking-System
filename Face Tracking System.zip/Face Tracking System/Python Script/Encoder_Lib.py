import serial
import time

class E2019Q:
    @staticmethod
    def Open_COM_Port(com_string, baudrate=9600, timeout=0.1):
        """
        Open the COM port specified by com_string.
        :param com_string: Port name (e.g., 'COM3' on Windows or '/dev/ttyUSB0' on Linux)
        :param baudrate: Baud rate (default 9600)
        :param timeout: Read timeout in seconds (default 0.1)
        :return: Serial port object
        """
        ser = serial.Serial(port=com_string, baudrate=baudrate, timeout=timeout)
        return ser


    @staticmethod
    def Close_COM_Port(ser):
        """
        Close the COM port.
        :param ser: Serial port object
        """
        ser.close()

    @staticmethod
    def _read_until_cr(ser, timeout=3):
        """
        Read from the serial port until a carriage return ('\r') is found or until a timeout occurs.
        :param ser: Serial port object
        :param timeout: Timeout in seconds (default 3)
        :return: The string received from the port.
        """
        data = ""
        start_time = time.time()
        while '\r' not in data:
            if ser.in_waiting > 0:
                # Read all available bytes and decode them as ASCII
                data += ser.read(ser.in_waiting).decode('ascii')
            if time.time() - start_time > timeout:
                print("Timeout occurs while reading COM port")
                break
            time.sleep(0.01)  # small delay to avoid busy waiting
        return data



    @staticmethod
    def GetSoftwareVersion(ser):
        """
        Send 'v' command to get the software version.
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('v'.encode('ascii'))
        return E2019Q._read_until_cr(ser)


    @staticmethod
    def GetSerialNumber(ser):
        """
        Send 's' command to get the serial number (internal serial number in 8 Hex numbers).
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('s'.encode('ascii'))
        return E2019Q._read_until_cr(ser)


    @staticmethod
    def GetInterfaceSerialNumber(ser):
        """
        Send 'r' command to get the interface product serial number (6 characters; written on interface housing).
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('r'.encode('ascii'))
        return E2019Q._read_until_cr(ser)


    @staticmethod
    def GetEncPosition(ser):
        """
        Send '?' command to read the encoder position in decimal representation.
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('?'.encode('ascii'))
        return E2019Q._read_until_cr(ser)


    @staticmethod
    def GetEncPositionHEX(ser):
        """
        Send '>' command to read the encoder position in HEX (8 Hex digits).
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('>'.encode('ascii'))
        return E2019Q._read_until_cr(ser)


    @staticmethod
    def GetEncPosition_Timestamp(ser):
        """
        Send '!' command to read the encoder position in decimal form with timestamp.
        (Returns 2 decimal values separated by a colon and terminated with CR.)
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('!'.encode('ascii'))
        return E2019Q._read_until_cr(ser)



    @staticmethod
    def GetEncPositionHEX_Timestamp(ser):
        """
        Send '<' command to read the encoder position in HEX form with timestamp.
        (Note: This command is not listed in the original command set but is provided for completeness.)
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('<'.encode('ascii'))
        return E2019Q._read_until_cr(ser)


    @staticmethod
    def GetEncPositionHEX64(ser):
        """
        Send '4' command to read a 16 character hexadecimal string + CR comprising 64 SLO bits,
        synchronized to 64 MA clocks.
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('4'.encode('ascii'))
        return E2019Q._read_until_cr(ser)


    @staticmethod
    def ReadWordWidth(ser):
        """
        Send 'b' command to read the current word width that is read from the encoder.
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('b'.encode('ascii'))
        return E2019Q._read_until_cr(ser)

    @staticmethod
    def SetWordWidth(ser, word_width):
        """
        Send 'B' command followed by the word width (one or two characters) and a carriage return
        to set the word width.
        :param ser: Serial port object
        :param word_width: Word width as a string (one or two characters)
        :return: Response string
        """
        command = "B" + str(word_width) + "\r"
        ser.write(command.encode('ascii'))
        return E2019Q._read_until_cr(ser)


    @staticmethod
    def GetEncoderClockFrequency(ser):
        """
        Send 'm' command to read the current encoder clock frequency.
        (For example, a response of "3" indicates 140 kHz.)
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('m'.encode('ascii'))
        return E2019Q._read_until_cr(ser)

    @staticmethod
    def SetEncoderClockFrequency(ser, frequency):
        """
        Send 'M' command followed by a digit (1-8) and a carriage return to set the SSI and BiSS clock frequency.
        Valid frequency values:
            8 = 4.4 MHz
            7 = 2.2 MHz
            6 = 1.1 MHz
            5 = 560 kHz
            4 = 280 kHz
            3 = 140 kHz (default)
            2 = 70 kHz
            1 = 35 kHz
        :param ser: Serial port object
        :param frequency: Clock frequency digit (as a string or integer, one of 8,7,6,5,4,3,2,1)
        :return: Response string
        """
        freq_str = str(frequency)
        if freq_str not in ['8', '7', '6', '5', '4', '3', '2', '1']:
            raise ValueError("Invalid frequency value. Must be one of '8','7','6','5','4','3','2','1'.")
        command = "M" + freq_str + "\r"
        ser.write(command.encode('ascii'))
        return E2019Q._read_until_cr(ser)

    @staticmethod
    def GetEncSupply(ser):
        """
        Send 'e' command to read encoder supply status, voltage, and current consumption.
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('e'.encode('ascii'))
        return E2019Q._read_until_cr(ser)


    @staticmethod
    def GetInputPinStatus(ser):
        """
        Send 'p' command to read the status of hardware input pins on the interface.
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('p'.encode('ascii'))
        return E2019Q._read_until_cr(ser)

    @staticmethod
    def EncSupply_ON(ser):
        """
        Send 'n' command to turn ON the encoder power supply.
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('n'.encode('ascii'))
        return E2019Q._read_until_cr(ser)



    @staticmethod
    def EncSupply_OFF(ser):
        """
        Send 'f' command to turn OFF the encoder power supply.
        :param ser: Serial port object
        :return: Response string
        """
        ser.write('f'.encode('ascii'))
        return E2019Q._read_until_cr(ser)

    @staticmethod
    def StartAutoTransmission(ser):
        """
        Send '1' command to begin auto transmission of the encoder position in decimal form
        at a 500 Hz rate.
        Note: Once started, the device will stream data continuously.
        :param ser: Serial port object
        """
        ser.write('1'.encode('ascii'))
        # Since the device sends data continuously, do not attempt to read a terminating CR here.



    @staticmethod
    def StopAutoTransmission(ser):
        """
        Send '0' command to stop auto transmission of the encoder position.
        :param ser: Serial port object
        """
        ser.write('0'.encode('ascii'))
        # No response is expected for stopping auto transmission.


    @staticmethod
    def ClearReferenceFlag(ser):
        """
        Send 'c' command to clear the reference status flag.
        :param ser: Serial port object
        """
        ser.write('c'.encode('ascii'))

    @staticmethod
    def ResetCurrentCount(ser):
        """
        Send 'z' command to set the current count value to zero (also resets the reference mark).
        :param ser: Serial port object
        """
        ser.write('z'.encode('ascii'))


    @staticmethod
    def ClearZeroOffset(ser):
        """
        Send 'a' command to clear the zero offset value stored by ResetCurrentCount.
        :param ser: Serial port object
        """
        ser.write('a'.encode('ascii'))

    @staticmethod
    def GetEncCountDOUBLE(ser):
        """
        Get the encoder count as a double precision number.
        It calls GetEncPosition and then extracts the number between the first character and the first colon.
        :param ser: Serial port object
        :return: Floating point number or None if conversion fails.
        """
        temp = E2019Q.GetEncPosition(ser)
        colon_index = temp.find(':')
        if colon_index == -1:
            return None
        try:
            return float(temp[1:colon_index])
        except ValueError:
            return None

    @staticmethod
    def GetEncReferenceDOUBLE(ser):
        """
        Get the encoder reference mark as a double precision number.
        It calls GetEncPosition and then extracts the number between the first and the last colon.
        :param ser: Serial port object
        :return: Floating point number or None if conversion fails.
        """
        temp = E2019Q.GetEncPosition(ser)
        first_colon = temp.find(':')
        last_colon = temp.rfind(':')
        if first_colon == -1 or last_colon == -1 or first_colon == last_colon:
            return None

        try:
            return float(temp[first_colon + 2:last_colon])
        except ValueError:
            return None

    @staticmethod

    def GetTimestampDOUBLE(ser):
        """
        Get the timestamp from the encoder position (with timestamp) as a double precision number.
        It calls GetEncPosition_Timestamp and then extracts the number after the last colon, omitting the last character.
        :param ser: Serial port object
        :return: Floating point number or None if conversion fails.
        """
        temp = E2019Q.GetEncPosition_Timestamp(ser)
        last_colon = temp.rfind(':')
        if last_colon == -1:
            return None
        try:
            # Exclude the final character (assumed to be a terminator) by using [last_colon+2:-1]
            return float(temp[last_colon + 2:-1])
        except ValueError:
            return None

"""
Notes:
- Open_COM_Port(com_string, baudrate, timeout):
    Opens the serial port with the given port name, baud rate, and timeout.

- Close_COM_Port(ser):
    Closes the opened serial port.

- GetSoftwareVersion(ser):
    Sends the 'v' command to retrieve the device's software version.

- GetSerialNumber(ser):
    Sends the 's' command to retrieve the device's internal serial number (8 Hex numbers).

- GetInterfaceSerialNumber(ser):
    Sends the 'r' command to retrieve the interface product serial number (6 characters).

- GetEncPosition(ser):
    Sends the '?' command to read the encoder position in decimal format.

- GetEncPositionHEX(ser):
    Sends the '>' command to read the encoder position in hexadecimal format (8 digits).

- GetEncPosition_Timestamp(ser):
    Sends the '!' command to read the encoder position in decimal format with a timestamp.

- GetEncPositionHEX_Timestamp(ser):
    Sends the '<' command to read the encoder position in hexadecimal format with a timestamp.

- GetEncPositionHEX64(ser):
    Sends the '4' command to retrieve a 16 character hexadecimal string (64 SLO bits).

- ReadWordWidth(ser):
    Sends the 'b' command to read the current word width.

- SetWordWidth(ser, word_width):
    Sends the 'Bnn+CR' command to set the word width (nn = one or two characters).

- GetEncoderClockFrequency(ser):
    Sends the 'm' command to read the current encoder clock frequency.

- SetEncoderClockFrequency(ser, frequency):
    Sends the 'Mn+CR' command to set the SSI and BiSS clock frequency.

- GetEncSupply(ser):
    Sends the 'e' command to read the encoder supply status, voltage, and current consumption.

- GetInputPinStatus(ser):
    Sends the 'p' command to read the status of hardware input pins on the interface.

- EncSupply_ON(ser) & EncSupply_OFF(ser):
    Sends the 'n' and 'f' commands to turn the encoder power supply on and off, respectively.

- StartAutoTransmission(ser) & StopAutoTransmission(ser):
    Sends the '1' and '0' commands to begin and stop auto transmission of the encoder position (500 Hz).

- ClearReferenceFlag(ser), ResetCurrentCount(ser), ClearZeroOffset(ser):
    Send the 'c', 'z', and 'a' commands to clear the reference flag, reset the current count, and clear the zero offset.

- GetEncCountDOUBLE(ser), GetEncReferenceDOUBLE(ser), GetTimestampDOUBLE(ser):
    These functions extract numerical values from the responses received from the encoder.
"""

