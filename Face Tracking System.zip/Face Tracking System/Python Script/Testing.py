import serial
import struct
import time
from datetime import datetime
import msvcrt
import cv2
import mediapipe as mp
import re
from Encoder_Lib import E2019Q

UART_PORT = 'COM6'
BAUD_RATE = 115200
ser = serial.Serial(UART_PORT, BAUD_RATE, timeout=0.1)
command_running = 0

def calculate_checksum(data):
    checksum = 0
    for byte in data:
        checksum ^= byte
    return checksum

def send_telecommand(direction1, steps1, direction2, steps2, speed, ser_port=ser):
    header = 0xAA
    end_byte = 0x55
    message = struct.pack('>B B I B I H', header, direction1, steps1, direction2, steps2, speed)
    checksum = calculate_checksum(message)
    message += struct.pack('B', checksum) + struct.pack('B', end_byte)
    ser_port.write(message)
    print(f"Sent: {message.hex()}")

def log_to_file(log_data):
    with open('log.txt', 'a') as log_file:
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        log_line = f"[{timestamp}] {log_data}\n"
        log_file.write(log_line)

def receive_telemetry():
    buffer = b""
    global command_running
    while command_running:
        if ser.in_waiting > 0:
            buffer += ser.read(ser.in_waiting)
            while len(buffer) >= 11:
                start_index = buffer.find(0xBB)
                if start_index == -1:
                    buffer = buffer[-10:]
                    break
                buffer = buffer[start_index:]
                if len(buffer) < 11:
                    break
                if buffer[10] == 0xEE:
                    telemetry_data = buffer[:11]
                    buffer = buffer[11:]
                    motor_id = telemetry_data[1]
                    direction = telemetry_data[2]
                    current_steps = struct.unpack('>I', telemetry_data[3:7])[0]
                    if current_steps >= 4000000000:
                        current_steps = 0
                    status1 = telemetry_data[7]
                    status2 = telemetry_data[8]
                    checksum = telemetry_data[9]
                    calculated_checksum = calculate_checksum(telemetry_data[:-2])
                    if checksum == calculated_checksum:
                        log_to_file(f'Motor {motor_id}, Dir {direction}, Steps {current_steps}, Status1 {status1}, Status2 {status2}')
                        if not status1 and not status2:
                            print("Steps Reached")
                            command_running = 0
                            break
                    else:
                        print("Checksum mismatch in telemetry!")
                        print(f"Actual: {checksum}, Calculated: {calculated_checksum}")
                else:
                    buffer = buffer[1:]
        time.sleep(0.01)

def ask_input():
    motor1_dir = input("Enter motor 1 direction: ")
    motor2_dir = input("Enter motor 2 direction: ")
    motor1_steps = input("Enter motor 1 steps: ")
    motor2_steps = input("Enter motor 2 steps: ")
    direction1 = int(motor1_dir)
    steps1 = int(motor1_steps)
    direction2 = int(motor2_dir)
    steps2 = int(motor2_steps)
    speed = 10000
    send_telecommand(direction1, steps1, direction2, steps2, speed)

def arrow_key_mode():
    global command_running
    print("Arrow key mode. Press 'q' to exit.")
    while True:
        if msvcrt.kbhit():
            key = msvcrt.getch()
            if key == b'q':
                break
            arrow = msvcrt.getch()
            if arrow == b'M':  # Right arrow
                send_telecommand(1, 200, 0, 0, 10000)
            elif arrow == b'K':  # Left arrow
                send_telecommand(0, 200, 0, 0, 10000)
            elif arrow == b'H':  # Up arrow
                send_telecommand(0, 0, 0, 100, 10000)
            elif arrow == b'P':  # Down arrow
                send_telecommand(0, 0, 1, 100, 10000)
            command_running = 1
            # receive_telemetry()
            command_running = 0
        time.sleep(0.01)

def face_detection_mode():
    width = 1280
    height = 720
    cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)
    if not cap.isOpened():
        print("Cannot open camera")
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, 30)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))

    mp_face_detection = mp.solutions.face_detection
    with mp_face_detection.FaceDetection(model_selection=0, min_detection_confidence=0.5) as face_detection:
        deadband = 30  
        scale_h = 0.5  
        scale_v = 0.5  
        speed = 10000  

        print("Face detection mode active. Press 'q' in the video window to exit.")
        while True:
            ret, frame = cap.read()
            if not ret:
                print("Failed to capture frame")
                break

            frame = cv2.resize(frame, (width, height))
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = face_detection.process(rgb_frame)

            if results.detections:
                detection = results.detections[0]
                bbox = detection.location_data.relative_bounding_box
                x = int(bbox.xmin * width)
                y = int(bbox.ymin * height)
                w = int(bbox.width * width)
                h = int(bbox.height * height)
                
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                cx = int(x + w / 2)
                cy = int(y + h / 2)
                cv2.circle(frame, (cx, cy), 5, (0, 0, 255), -1)
                cv2.putText(frame, f"({cx}, {cy})", (cx, cy - 10), cv2.FONT_HERSHEY_SIMPLEX,
                            0.6, (255, 0, 0), 2)
                
                error_x = cx - (width // 2)
                error_y = cy - (height // 2)
                cv2.putText(frame, f"Error: ({error_x}, {error_y})", (50, 50), cv2.FONT_HERSHEY_SIMPLEX,
                            0.8, (0, 255, 255), 2)
                
                motor1_dir = 0
                motor1_steps = 0
                motor2_dir = 0
                motor2_steps = 0

                if abs(error_x) > deadband:
                    motor1_steps = int(abs(error_x) * scale_h)
                    motor1_dir = 1 if error_x > 0 else 0

                if abs(error_y) > deadband:
                    motor2_steps = int(abs(error_y) * scale_v)
                    motor2_dir = 1 if error_y > 0 else 0

                if motor1_steps != 0 or motor2_steps != 0:
                    print(f"Commanding: Motor1 -> Dir: {motor1_dir}, Steps: {motor1_steps}; "
                          f"Motor2 -> Dir: {motor2_dir}, Steps: {motor2_steps}")
                    send_telecommand(motor1_dir, motor1_steps, motor2_dir, motor2_steps, speed)
                    time.sleep(0.05)

            cv2.imshow("Face Detection", frame)
            key = cv2.waitKey(1)
            if key & 0xFF == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()

def calculate_steps_from_encoder(current_count, setpoint, wrapped_mode=False, pole_count=180, interpolation_factor=200):
    CPR = pole_count * interpolation_factor
    angle_resolution = 360 / CPR
    current_angle = current_count * angle_resolution

    if wrapped_mode:
        current_angle %= 360
        setpoint %= 360
        error_angle = ((setpoint - current_angle + 180) % 360) - 180
    else:
        error_angle = setpoint - current_angle

    steps_needed = int(error_angle / angle_resolution)
    direction = 1 if steps_needed >= 0 else 0
    return abs(steps_needed), direction

def dual_encoder_setpoint_mode():
    print("Select setpoint mode:")
    print("1. Standard mode (raw angles)")
    print("2. Wrapped mode (0-360°)")
    mode_input = input("Enter 1 or 2: ").strip()
    wrapped_mode = True if mode_input == "2" else False

    while True:
        try:
            setpoint1 = float(input("Enter desired setpoint angle for Motor 1 (°): ").strip())
            break
        except ValueError:
            print("Invalid input. Please enter a numeric value.")

    while True:
        try:
            setpoint2 = float(input("Enter desired setpoint angle for Motor 2 (°): ").strip())
            break
        except ValueError:
            print("Invalid input. Please enter a numeric value.")

    ENCODER_PORT1 = 'COM16'
    ENCODER_PORT2 = 'COM15'
    TELECOMMAND_PORT = 'COM6'
    pole_count = 180
    interpolation_factor = 200
    speed = 500 

    try:
        encoder_ser1 = E2019Q.Open_COM_Port(ENCODER_PORT1, baudrate=9600, timeout=0.1)
        encoder_ser2 = E2019Q.Open_COM_Port(ENCODER_PORT2, baudrate=9600, timeout=0.1)
        # motor_ser = serial.Serial(TELECOMMAND_PORT, 115200, timeout=0.1)
        motor_ser= ser
        print(f"Opened encoder ports {ENCODER_PORT1} & {ENCODER_PORT2} and motor command port {TELECOMMAND_PORT} successfully.")
    except Exception as e:
        print(f"Failed to open ports: {e}")
        return

    try:
        print("Starting auto transmission from both encoders...")
        E2019Q.StartAutoTransmission(encoder_ser1)
        E2019Q.StartAutoTransmission(encoder_ser2)
        start_time = time.time()

        last_count1 = 0
        last_count2 = 0

        while time.time() - start_time < 60:
            if encoder_ser1.in_waiting:
                data1 = encoder_ser1.read(encoder_ser1.in_waiting).decode('ascii', errors='replace')
                for line in data1.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    match = re.search(r'(\d+)', line)
                    if match:
                        last_count1 = int(match.group(1))

            if encoder_ser2.in_waiting:
                data2 = encoder_ser2.read(encoder_ser2.in_waiting).decode('ascii', errors='replace')
                for line in data2.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    match = re.search(r'(\d+)', line)
                    if match:
                        last_count2 = int(match.group(1))
            
            steps1, direction1 = calculate_steps_from_encoder(last_count1, setpoint1, wrapped_mode, pole_count, interpolation_factor)
            steps2, direction2 = calculate_steps_from_encoder(last_count2, setpoint2, wrapped_mode, pole_count, interpolation_factor)

            print(f"Encoder1 Count: {last_count1}, Motor1 -> Steps: {steps1}, Direction: {'CW' if direction1 else 'CCW'}")
            print(f"Encoder2 Count: {last_count2}, Motor2 -> Steps: {steps2}, Direction: {'CW' if direction2 else 'CCW'}")

            send_telecommand(direction1, steps1, direction2, steps2, speed, ser_port=motor_ser)
            time.sleep(0.5)

        print("Stopping auto transmission from encoders...")
        E2019Q.StopAutoTransmission(encoder_ser1)
        E2019Q.StopAutoTransmission(encoder_ser2)

    except Exception as e:
        print(f"An error occurred in dual encoder setpoint mode: {e}")
    finally:
        E2019Q.Close_COM_Port(encoder_ser1)
        E2019Q.Close_COM_Port(encoder_ser2)
        print("Encoder ports closed.")
        motor_ser.close()
        print("Motor command port closed.")

if __name__ == "__main__":
    try:
        print("Select mode:")
        print("1: Manual Input")
        print("2: Arrow Keys")
        print("3: Face Detection")
        print("4: Dual Encoder Setpoint Mode")
        mode = input("Enter mode number: ").strip()
        if mode == "1":
            while True:
                ask_input()
                time.sleep(1)
                command_running = 1
                receive_telemetry()
                command_running = 0
        elif mode == "2":
            arrow_key_mode()
        elif mode == "3":
            face_detection_mode()
        elif mode == "4":
            dual_encoder_setpoint_mode()
        else:
            print("Invalid mode selected.")
    except KeyboardInterrupt:
        print("Terminating...")
    finally:
        ser.close()
